# Polymarket Trading Bot (Python)

Standalone Python repository for the Polymarket trading bot.

## Requirements

- Python 3.10+
- Polymarket API credentials (for live trading)

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

Paper trading mode:

```bash
python polymarket_trader.py --paper --auto-slug --slug-prefix "will-bitcoin"
```

Live trading mode:

```bash
export POLY_PRIVATE_KEY=...
export POLY_FUNDER=...
export POLY_API_KEY=...
export POLY_API_SECRET=...
export POLY_API_PASSPHRASE=...
python polymarket_trader.py --slug "example-market-slug"
```

## Model

- Default model path: `./prob_model_logit_all.json`
- Override with `--model-path /path/to/model.json`

## Key Flags

- `--paper`
- `--slug`
- `--auto-slug --slug-prefix`
- `--signals-only`
- `--dry-run`
