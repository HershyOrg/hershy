import json
import math
from pathlib import Path
from typing import Tuple


def sigmoid_scalar(z: float) -> float:
    z = max(-50.0, min(50.0, z))
    return 1.0 / (1.0 + math.exp(-z))


def load_prob_model_from_path(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"prob model not found: {path}")
    return json.loads(path.read_text())


def prob_predict(
    model: dict,
    delta_pct: float,
    cum_vol_1h: float,
    mom: float,
    regime: int,
    tau_sec: int,
) -> float:
    w = model["w"]
    mu = model["mu"]
    sd = model["sd"]
    tau_norm_div = float(model.get("tau_norm_div", 240.0))
    if tau_norm_div <= 0:
        tau_norm_div = 240.0

    x0 = delta_pct
    x1 = math.log1p(max(cum_vol_1h, 0.0))
    x2 = mom
    x3 = float(regime)
    x4 = float(tau_sec) / tau_norm_div

    xs = [
        (x0 - mu[0]) / (sd[0] if sd[0] else 1.0),
        (x1 - mu[1]) / (sd[1] if sd[1] else 1.0),
        (x2 - mu[2]) / (sd[2] if sd[2] else 1.0),
        (x3 - mu[3]) / (sd[3] if sd[3] else 1.0),
        (x4 - mu[4]) / (sd[4] if sd[4] else 1.0),
    ]

    z = w[0] + sum(w[i + 1] * xs[i] for i in range(5))
    p = sigmoid_scalar(z)
    return max(0.0, min(1.0, p))


def compute_pbad(p_up: float, p_t: float, o_1h: float) -> Tuple[float, int]:
    sgn = 1 if (p_t - o_1h) >= 0 else -1
    if sgn == 1:
        p_bad = 1.0 - p_up
    else:
        p_bad = p_up
    return p_bad, sgn
